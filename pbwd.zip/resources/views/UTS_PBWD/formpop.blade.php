<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="stylee.css">
    <title>Form Tambah Data</title>
</head>
<body>
    <h1> Form Tambah Data </h1>
    <hr>
    <br>

    <table>
        <tr>
            <th>
                <label for="">Nama Produk</label>
            </th>
            <td>:</td>
            <td>
                <input type="text">
            </td>
        </tr>
        <tr>
            <th>
                <label for="">Rasa</label>
            </th>
            <td>:</td>
            <td>
                <input type="text">
            </td>
        </tr>
        <tr>
            <th>
                <label for="">Pcs</label>
            </th>
            <td>:</td>
            <td>
                <input type="number">
            </td>
        </tr>
        <tr>
            <th>
                <label for="">Harga</label>
            </th>
            <td>:</td>
            <td>
                <input type="number">
            </td>
        </tr>
        <tr>
            <td colspan="3">
                <button class="simpan">SIMPAN</button>
            </td>
        </tr>
    </table>
</body>
</html>