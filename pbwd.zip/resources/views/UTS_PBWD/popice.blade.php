<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="stylee.css">
    <title> Produk Pop Ice </title>
</head>
<body>
    <h1> Table Produk Pop Ice </h1>
    <hr>
    <br>

    <table>
        <thead>
            <tr>
                <th> No </th>
                <th> Nama Produk </th>
                <th> Rasa </th>
                <th> Pcs </th>
                <th> Harga </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td> 1 </td>
                <td> Pop Ice Milk Shake Powder Chocolate </td>
                <td> Coklat </td>
                <td> 10 </td>
                <td> Rp 12.000 </td>
            </tr>
            <tr>
                <td> 2 </td>
                <td> Pop Ice Milk Shake Powder Mango </td>
                <td> Mangga </td>
                <td> 10 </td>
                <td> Rp 12.000 </td>
            </tr>
            <tr>
                <td> 3 </td>
                <td> Pop Ice Active Thunder Choco Malt </td>
                <td> Choco Malt </td>
                <td> 10 </td>
                <td> Rp 12.000 </td>
            </tr>
        </tbody>
    </table>
</body>
</html>